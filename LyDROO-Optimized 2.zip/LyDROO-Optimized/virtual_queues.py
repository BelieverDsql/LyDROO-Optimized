# -*- coding: utf-8 -*-
"""
【论文创新点2：虚拟队列的Lyapunov-AC任务卸载算法】

本模块实现基于Lyapunov优化理论的虚拟队列机制：
1. 数据队列Q: 跟踪待处理的数据任务积压情况
2. 虚拟能量队列Y: 将能量阈值约束转化为队列稳定性问题

Lyapunov优化核心思想：
- 通过构造虚拟队列，将长期约束问题转化为瞬时队列稳定性问题
- 队列稳定即意味着长期约束满足

参考文献：
- Neely M J. Stochastic network optimization with application to communication and queueing systems[M]. 2010
- Bi S, et al. Lyapunov-guided deep reinforcement learning for stable online computation offloading[J]. 2021
"""

import numpy as np


class DataQueue:
    """
    【核心创新点2：数据队列】

    数据队列Q用于跟踪待处理的数据任务积压情况。

    数据队列更新原理：
    - Q[t+1] = max(Q[t] + A[t] - R[t], 0)
    - 其中 A[t] 为新到达任务，R[t] 为处理速率
    """

    def __init__(self, N):
        """
        初始化数据队列

        参数:
            N: 用户数量
        """
        self.N = N
        self.Q = np.zeros(N)  # 数据队列 (Mbits)

        # 历史记录
        self.Q_history = []

    def update(self, data_arrival, computation_rate):
        """
        更新数据队列

        更新公式: Q[t+1] = max(Q[t] + A[t] - R[t], 0)

        参数:
            data_arrival: 数据到达率 (Mbits)
            computation_rate: 计算速率 (Mbits/time_slot)

        返回:
            Q: 更新后的数据队列
        """
        Q_next = np.maximum(self.Q + data_arrival - computation_rate, 0)
        self.Q = Q_next
        self.Q_history.append(Q_next.copy())

        return self.Q.copy()

    def get_queue_length(self):
        """获取队列长度（用于Lyapunov函数计算）"""
        return np.sum(self.Q ** 2)

    def get_mean_queue_length(self):
        """获取平均队列长度"""
        if len(self.Q_history) == 0:
            return 0
        return np.mean([np.sum(q) for q in self.Q_history[-100:]])

    def is_stable(self, window=50, threshold=1e6):
        """
        检查队列是否稳定

        参数:
            window: 窗口大小
            threshold: 稳定性阈值

        返回:
            is_stable: 队列是否稳定
        """
        if len(self.Q_history) < window:
            return True

        recent = self.Q_history[-window:]
        avg_length = np.mean([np.sum(q) for q in recent])

        return avg_length < threshold

    def reset(self):
        """重置队列"""
        self.Q = np.zeros(self.N)
        self.Q_history = []


class VirtualQueueManager:
    """
    【核心创新点2：虚拟队列管理器】

    整合数据队列Q和虚拟能量队列Y，统一管理Lyapunov优化所需的队列系统。

    虚拟队列设计原理：
    - 数据队列Q: 跟踪任务积压，确保队列稳定性
    - 虚拟能量队列Y: 将能量约束转化为队列稳定性
    - Lyapunov函数: L(t) = 1/2 * Σ(Q_i^2 + Y_i^2)
    """

    def __init__(self, N, energy_threshold=0.35, nu=10, enable_queue_constraint=False, queue_threshold=None):
        """
        初始化虚拟队列管理器

        参数:
            N: 用户数量
            energy_threshold: 能量阈值 (J/time_slot)
            nu: 能量队列因子
            enable_queue_constraint: 是否启用队列长度约束
            queue_threshold: 队列长度阈值
        """
        self.N = N
        self.energy_threshold = energy_threshold
        self.nu = nu
        self.enable_queue_constraint = enable_queue_constraint
        self.queue_threshold = queue_threshold if queue_threshold else 1000

        # 初始化数据队列
        self.data_queue = DataQueue(N)

        # 初始化虚拟能量队列
        from energy_threshold import EnergyQueue
        self.energy_queue = EnergyQueue(N, energy_threshold, nu)

        # 可选：队列长度约束队列
        if enable_queue_constraint:
            self.Z = np.zeros(N)  # 队列长度约束虚拟队列
        else:
            self.Z = np.zeros(N)

        # 历史记录
        self.lyapunov_history = []

    def get_lyapunov_function(self):
        """
        获取Lyapunov函数值

        Lyapunov函数定义:
        L(t) = 0.5 * sum(Q_i^2) + 0.5 * sum(Y_i^2)

        返回:
            L: Lyapunov函数值
        """
        L = 0.5 * self.data_queue.get_queue_length() + \
            0.5 * self.energy_queue.get_queue_length()

        if self.enable_queue_constraint:
            L += 0.5 * np.sum(self.Z ** 2)

        return L

    def compute_drift(self):
        """
        计算Lyapunov漂移

        漂移 = L(t+1) - L(t)

        返回:
            drift: Lyapunov漂移值
        """
        L_current = self.get_lyapunov_function()

        # 假设下一时刻队列不变（简化计算）
        # 实际应用中需要根据预测计算
        L_next = L_current  # 临时占位

        drift = L_next - L_current
        return drift

    def update(self, data_arrival, computation_rate, energy_consumption):
        """
        更新所有虚拟队列

        参数:
            data_arrival: 数据到达率 (Mbits)
            computation_rate: 计算速率 (Mbits/time_slot)
            energy_consumption: 能耗 (J/time_slot)

        返回:
            Q, Y: 更新后的队列状态
        """
        # 更新数据队列
        Q = self.data_queue.update(data_arrival, computation_rate)

        # 更新虚拟能量队列
        Y = self.energy_queue.update(energy_consumption)

        # 可选：更新队列长度约束队列
        if self.enable_queue_constraint:
            queue_excess = np.maximum(self.Q - self.queue_threshold, 0)
            self.Z = np.maximum(self.Z + queue_excess, 0)

        # 记录Lyapunov函数值
        L = self.get_lyapunov_function()
        self.lyapunov_history.append(L)

        return Q.copy(), Y.copy()

    def compute_drift_penalty(self, V, w):
        """
        计算漂移-惩罚上界

        根据Lyapunov优化理论：
        ΔL(t) + V * J(t) <= C + Σ(Q_i + V*w_i) * (A_i - r_i)
                           - Σ Y_i * (e_i - E_thresh)

        参数:
            V: 控制参数，权衡性能与队列稳定性
            w: 用户权重

        返回:
            drift_penalty: 漂移-惩罚上界
        """
        # 简化的漂移-惩罚计算
        Q_sum = np.sum(self.data_queue.Q)
        Y_sum = np.sum(self.energy_queue.Y)

        # 漂移-惩罚上界（简化形式）
        drift_penalty = Q_sum + V * w - Y_sum * self.nu

        return drift_penalty

    def get_state(self, Q_scale=10000, Y_scale=10000):
        """
        获取归一化的队列状态用于神经网络输入

        参数:
            Q_scale: 数据队列缩放因子
            Y_scale: 能量队列缩放因子

        返回:
            state: 归一化后的队列状态 [N*2]
        """
        return np.concatenate([
            self.data_queue.Q / Q_scale,
            self.energy_queue.Y / Y_scale
        ])

    def check_stability(self):
        """
        检查队列稳定性

        返回:
            is_stable: 队列是否稳定
            info: 详细稳定性信息
        """
        data_stable = self.data_queue.is_stable()
        energy_stable = self.energy_queue.is_stable()

        is_stable = data_stable and energy_stable

        info = {
            'data_queue_stable': data_stable,
            'energy_queue_stable': energy_stable,
            'data_queue_mean': self.data_queue.get_mean_queue_length(),
            'lyapunov_value': self.get_lyapunov_function()
        }

        return is_stable, info

    def reset(self):
        """重置所有队列"""
        self.data_queue.reset()
        self.energy_queue.reset()
        self.Z = np.zeros(self.N)
        self.lyapunov_history = []


def compute_drift_penalty_upper_bound(Q, Y, w, V, data_arrival):
    """
    计算漂移-惩罚上界（独立函数）

    根据Lyapunov优化理论，漂移-惩罚项的上界可表示为:

    ΔL(t) + V * J(t) <= C + Σ (Q_i + V*w_i) * (A_i - r_i)
                       - Σ Y_i * (e_i - E_thresh)

    参数:
        Q: 数据队列长度
        Y: 虚拟能量队列
        w: 用户权重
        V: 控制参数
        data_arrival: 数据到达率

    返回:
        upper_bound: 漂移-惩罚上界
    """
    # 常数项（与决策无关）
    C = 0.5 * np.sum(data_arrival ** 2)

    # 计算权重系数 a_i = Q_i + V * w_i
    a = Q + V * w

    return C, a


if __name__ == "__main__":
    # 测试虚拟队列模块
    print("=" * 60)
    print("虚拟队列模块测试")
    print("=" * 60)

    # 测试 DataQueue
    data_queue = DataQueue(N=10)

    print("\n【数据队列测试】")
    for t in range(10):
        arrival = np.random.exponential(2, 10)
        rate = np.random.uniform(1, 5, 10)
        Q = data_queue.update(arrival, rate)
        if t % 5 == 0:
            print(f"  时隙 {t}: Q_sum = {np.sum(Q):.4f}, 稳定 = {data_queue.is_stable()}")

    # 测试 VirtualQueueManager
    queue_manager = VirtualQueueManager(N=10, energy_threshold=0.35, nu=10)

    print("\n【虚拟队列管理器测试】")
    for t in range(10):
        arrival = np.random.exponential(2, 10)
        rate = np.random.uniform(1, 5, 10)
        energy = np.random.uniform(0.2, 0.4, 10)

        Q, Y = queue_manager.update(arrival, rate, energy)

        if t % 5 == 0:
            L = queue_manager.get_lyapunov_function()
            is_stable, info = queue_manager.check_stability()
            print(f"  时隙 {t}: L = {L:.4f}, Q_sum = {np.sum(Q):.4f}, Y_sum = {np.sum(Y):.4f}")
            print(f"         稳定 = {is_stable}, 数据队列均值 = {info['data_queue_mean']:.4f}")

    print("\n测试完成!")