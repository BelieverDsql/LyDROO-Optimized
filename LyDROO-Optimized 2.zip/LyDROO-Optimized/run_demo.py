# -*- coding: utf-8 -*-
"""
演示程序启动脚本
使用方法: python run_demo.py
"""

import subprocess
import sys
import os

def main():
    # 获取当前目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    app_path = os.path.join(current_dir, "demo_app.py")

    print("=" * 60)
    print("启动 Lyapunov-AC 任务卸载演示程序")
    print("=" * 60)
    print(f"\n程序路径: {app_path}")
    print("\n正在启动Streamlit服务...")
    print("请在浏览器中访问: http://localhost:8501")
    print("\n按 Ctrl+C 停止服务")
    print("=" * 60)

    # 使用streamlit run命令启动
    cmd = [sys.executable, "-m", "streamlit", "run", app_path,
           "--server.port", "8501",
           "--server.headless", "true"]

    try:
        subprocess.run(cmd, cwd=current_dir)
    except KeyboardInterrupt:
        print("\n\n演示程序已停止")

if __name__ == "__main__":
    main()