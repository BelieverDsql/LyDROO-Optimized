# 基于Lyapunov-AC强化学习的移动边缘计算任务卸载

## 论文核心创新点

### 创新点1：基于能量阈值约束

本算法采用**能量阈值约束**机制限制每时隙的能耗：

- **能量阈值**: 设定每时隙最大能耗 $E_{thresh} = 0.35J$
- **约束机制**: 每时隙能耗 $E[t]$ 不得超过阈值
- **自适应调整**: 根据近期能耗动态优化阈值

### 创新点2：虚拟队列的Lyapunov-AC任务卸载算法

在能量阈值约束基础上，采用**Lyapunov优化理论**将长期约束问题转化为瞬时队列稳定性问题：

- **数据队列 Q**: 跟踪待处理数据任务积压
  - 更新公式: $Q[t+1] = \max(Q[t] + A[t] - R[t], 0)$

- **虚拟能量队列 Y**: 将能量阈值约束转化为队列稳定性
  - 更新公式: $Y[t+1] = \max(Y[t] + (E[t] - E_{thresh}) \cdot \nu, 0)$
  - 当 $E[t] > E_{thresh}$ 时队列增长，反之减少
  - Y队列稳定 → 长期平均能耗 ≤ 阈值

- **Lyapunov函数**: $L(t) = \frac{1}{2}\sum(Q_i^2 + Y_i^2)$
- **漂移-惩罚**: $\Delta L(t) + V \cdot E[t]$

---

## 项目简介

本项目实现了基于Lyapunov-AC（Actor-Critic）强化学习的移动边缘计算（MEC）任务卸载算法，用于优化多用户MEC系统中的任务卸载决策。

### 核心特性

- **Lyapunov优化**: 使用虚拟队列保证队列稳定性
- **Actor-Critic架构**: Actor生成卸载策略，Critic评估并分配资源
- **动作量化**: 支持OP、KNN、OPN等多种量化策略
- **能量阈值约束**: 满足每时隙能耗不超过阈值

## 文件结构

```
LyDROO-Optimized/
├── config.py              # 配置文件，包含所有算法参数
├── energy_threshold.py    # 【创新点1】能量阈值约束模块
│   ├── EnergyThresholdManager  # 自适应能量阈值管理器
│   └── EnergyQueue             # 虚拟能量队列
├── virtual_queues.py      # 【创新点2】虚拟队列模块
│   ├── DataQueue               # 数据队列
│   └── VirtualQueueManager    # 虚拟队列管理器
├── lyapunov_ac.py        # Lyapunov-AC核心算法
│   └── LyapunovACCore         # 核心算法实现
├── actor.py              # Actor网络和动作量化
├── critic.py             # Critic网络和资源分配
├── queues.py             # 兼容旧版本的队列实现
├── main.py               # 主程序，包含训练和基准对比
└── README.md             # 本文件
```

## 环境要求

- Python 3.8+
- PyTorch 1.9+
- NumPy
- Matplotlib

安装依赖:
```bash
pip install torch numpy matplotlib
```

## 使用方法

### 1. 运行训练

```bash
python main.py
```

训练完成后会自动:
- 显示训练过程监控
- 运行基准算法对比实验
- 生成训练曲线图 `training_results.png`
- 保存模型到 `models/` 目录

### 2. 修改配置参数

编辑 `config.py` 文件:

```python
# ========== 论文重点参数 ==========
self.V = 10                      # Lyapunov控制参数
self.nu = 10                     # 能量队列因子
self.energy_threshold = 0.35     # 能量阈值约束 (J/time_slot)

# 系统参数
self.N = 10                      # 用户数量
self.n_frames = 500              # 训练帧数
```

## 算法原理

### 1. 虚拟队列机制（创新点1）

```
原始约束问题:              转化为队列稳定性问题:
─────────────────         ─────────────────────────
min E[t]                  保持 Q[t] 稳定
s.t. E[t] ≤ E_thresh      保持 Y[t] 稳定
```

Lyapunov函数:
$$L(t) = \frac{1}{2}\sum_{i=1}^{N}(Q_i^2(t) + Y_i^2(t))$$

漂移-惩罚函数:
$$\Delta L(t) + V \cdot \mathbb{E}[E(t)]$$

### 2. 能量阈值约束（创新点2）

- 设定能量阈值 $E_{thresh} = 0.35J$
- 每时隙能耗 $E[t]$ 不得超过阈值
- 通过虚拟队列Y将约束转化为可优化目标

### 任务卸载流程

1. **状态获取**: 读取队列状态(Q, Y)和数据到达率
2. **动作生成**: Actor网络输出卸载偏好 $p \in [0, 1]$
3. **动作量化**: 将连续动作离散化
4. **资源分配**: 计算本地/边缘处理的时延和能耗
5. **奖励计算**: 结合时延、能耗和队列稳定性
6. **队列更新**: 更新数据队列Q和虚拟能量队列Y
7. **策略更新**: 根据奖励更新网络参数

## 基准算法对比

程序会自动与以下基准算法对比:

1. **全部本地处理**: $p = 0$，所有任务本地计算
2. **全部边缘卸载**: $p = 1$，所有任务卸载到MEC服务器
3. **随机卸载策略**: $p \sim U(0, 1)$，随机选择卸载比例

## 实验结果

典型训练结果:

| 指标 | 初始值 | 最终值 | 改善 |
|------|--------|--------|------|
| 时延 | ~5.5s | ~1.0s | ↓82% |
| 能耗 | ~0.55J | ~0.1J | ↓82% |
| Y队列 | 不稳定 | 稳定 | 收敛 |

## 毕业设计对应

本实现对应开题报告《基于Lyapunov-AC强化学习的移动边缘计算任务卸载方法研究》:

| 论文要求 | 实现对应 | 模块位置 |
|----------|----------|----------|
| ✅ 基于Lyapunov-AC强化学习 | LyapunovAC类 | main.py |
| ✅ 虚拟队列设计（数据队列Q、能量队列Y） | DataQueue + EnergyQueue | virtual_queues.py |
| ✅ 能量阈值约束 | EnergyThresholdManager | energy_threshold.py |
| ✅ 任务卸载决策（p值） | ActorNetwork | actor.py |
| ✅ 资源分配（Shannon公式） | ResourceAllocator | critic.py |
| ✅ 基准算法对比实验 | run_benchmark() | main.py |

### 模块说明

**创新点1：能量阈值约束** → `energy_threshold.py`
- `EnergyThresholdManager`: 自适应调整能量阈值
- `EnergyQueue`: 虚拟能量队列，将能量约束转化为队列稳定性

**创新点2：虚拟队列Lyapunov-AC** → `virtual_queues.py`
- `DataQueue`: 数据队列，跟踪任务积压
- `VirtualQueueManager`: 统一管理虚拟队列，计算Lyapunov函数

**核心算法** → `lyapunov_ac.py`
- `LyapunovACCore`: 整合两大创新点的核心算法实现

## 注意事项

1. 首次训练可能需要几分钟时间
2. 确保有足够的磁盘空间保存模型和图片
3. 如遇到内存问题，可减小 `batch_size` 参数