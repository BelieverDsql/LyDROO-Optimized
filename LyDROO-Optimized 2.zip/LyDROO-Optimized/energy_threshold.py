# -*- coding: utf-8 -*-
"""
【论文创新点1：能量阈值约束算法】

本模块实现能量阈值约束机制：
1. 能量阈值 E_thresh: 限制每时隙最大能耗
2. 自适应调整: 根据历史能耗动态优化阈值
3. 能量队列: 将能量约束转化为队列稳定性问题

参考文献：
- Mao Y, et al. Dynamic computation offloading for mobile-edge computing with energy harvesting devices[J]. 2016
- Chen Y, et al. Energy efficient dynamic offloading in mobile edge computing for Internet of Things[J]. 2021
- Bi S, et al. Lyapunov-guided deep reinforcement learning for stable online computation offloading[J]. 2021
"""

import numpy as np


class EnergyThresholdManager:
    """
    【核心创新点1：能量阈值约束管理器】

    自适应能量阈值管理器，根据近期能量消耗动态调整能量阈值。

    能量阈值约束机制：
    - 设定能量阈值E_thresh，约束每时隙能耗E[t] <= E_thresh
    - 通过Lyapunov虚拟队列Y实现长期能量约束
    - 自适应调整机制：根据实际能耗动态优化阈值
    """

    def __init__(self, initial_threshold=0.35, learning_rate=0.01, window_size=50):
        """
        初始化能量阈值管理器

        参数:
            initial_threshold: 初始能量阈值 (J/time_slot)
            learning_rate: 学习率，控制阈值调整速度
            window_size: 滑动窗口大小，用于计算平均能耗
        """
        self.threshold = initial_threshold
        self.initial_threshold = initial_threshold
        self.learning_rate = learning_rate
        self.window_size = window_size

        # 历史记录
        self.energy_history = []
        self.threshold_history = [initial_threshold]

        # 统计信息
        self.total_energy = 0
        self.count = 0

    def update(self, energy_consumption):
        """
        更新能量阈值

        基于近期平均能量消耗自适应调整阈值

        参数:
            energy_consumption: 当前时隙总能耗 (J)

        返回:
            threshold: 更新后的能量阈值
        """
        self.total_energy += energy_consumption
        self.count += 1
        self.energy_history.append(energy_consumption)

        # 保持历史窗口大小
        if len(self.energy_history) > self.window_size:
            self.energy_history.pop(0)

        # 计算近期平均能耗
        if len(self.energy_history) >= 10:
            avg_energy = np.mean(self.energy_history[-10:])

            # 调整阈值：向平均能耗方向移动，实现自适应
            self.threshold += self.learning_rate * (avg_energy - self.threshold)

            # 限制阈值范围，防止过度调整
            self.threshold = np.clip(self.threshold, 0.01, 0.5)

        self.threshold_history.append(self.threshold)

        return self.threshold

    def get_threshold(self):
        """获取当前能量阈值"""
        return self.threshold

    def get_statistics(self):
        """获取统计信息"""
        if self.count == 0:
            return {
                'avg_energy': 0,
                'threshold': self.threshold,
                'constraint_satisfied': True
            }

        avg_energy = self.total_energy / self.count
        constraint_satisfied = avg_energy <= self.threshold

        return {
            'avg_energy': avg_energy,
            'threshold': self.threshold,
            'constraint_satisfied': constraint_satisfied,
            'total_samples': self.count
        }

    def reset(self):
        """重置到初始阈值"""
        self.threshold = self.initial_threshold
        self.energy_history = []
        self.total_energy = 0
        self.count = 0


class EnergyQueue:
    """
    【核心创新点1：虚拟能量队列】

    将能量阈值约束转化为队列稳定性问题。

    虚拟能量队列Y的构造原理：
    - 原始约束: E[t] <= E_thresh (每时隙能耗不超过阈值)
    - 引入松弛变量: Y[t+1] = max(Y[t] + (E[t] - E_thresh), 0)
    - 当E[t] > E_thresh时，Y队列增长；反之减少
    - Y队列稳定意味着长期平均能耗 <= 阈值
    """

    def __init__(self, N, energy_threshold=0.35, nu=10):
        """
        初始化虚拟能量队列

        参数:
            N: 用户数量
            energy_threshold: 能量阈值 (J/time_slot)
            nu: 能量队列因子，控制惩罚力度
        """
        self.N = N
        self.energy_threshold = energy_threshold
        self.nu = nu

        # 虚拟能量队列 Y[i] 表示用户i的能量队列积压
        self.Y = np.zeros(N)

        # 历史记录
        self.Y_history = []

    def update(self, energy_consumption):
        """
        更新虚拟能量队列

        更新公式: Y[t+1] = max(Y[t] + (E[t] - E_thresh) * nu, 0)

        参数:
            energy_consumption: 各用户能耗数组 [N]

        返回:
            Y: 更新后的能量队列
        """
        # 计算能量偏差（超过阈值的部分）
        energy_excess = energy_consumption - self.energy_threshold

        # 更新队列：累积超过阈值的部分
        Y_next = np.maximum(self.Y + energy_excess * self.nu, 0)

        self.Y = Y_next
        self.Y_history.append(Y_next.copy())

        return self.Y.copy()

    def get_queue_length(self):
        """获取队列长度（用于Lyapunov函数计算）"""
        return np.sum(self.Y ** 2)

    def is_stable(self, window=50):
        """
        检查队列是否稳定

        参数:
            window: 窗口大小

        返回:
            is_stable: 队列是否稳定
        """
        if len(self.Y_history) < window:
            return True

        # 检查队列是否发散
        recent = self.Y_history[-window:]
        avg_length = np.mean([np.sum(y ** 2) for y in recent])

        return avg_length < 1e6  # 阈值可根据实际情况调整

    def reset(self):
        """重置队列"""
        self.Y = np.zeros(self.N)
        self.Y_history = []


def compute_energy_drift_penalty(Y, energy_threshold, V):
    """
    计算能量队列的漂移-惩罚项

    参数:
        Y: 虚拟能量队列
        energy_threshold: 能量阈值
        V: 控制参数

    返回:
        drift_penalty: 漂移-惩罚值
    """
    # 能量队列贡献的漂移-惩罚项
    # -Σ Y_i * (e_i - E_thresh)
    energy_excess = energy_threshold  # 简化表示
    drift_penalty = -np.sum(Y) * energy_excess * V

    return drift_penalty


if __name__ == "__main__":
    # 测试能量阈值约束模块
    print("=" * 60)
    print("能量阈值约束模块测试")
    print("=" * 60)

    # 测试 EnergyThresholdManager
    threshold_manager = EnergyThresholdManager(
        initial_threshold=0.35,
        learning_rate=0.01,
        window_size=50
    )

    # 模拟能量消耗
    np.random.seed(42)
    for t in range(100):
        energy = np.random.uniform(0.2, 0.4)
        threshold_manager.update(energy)

    stats = threshold_manager.get_statistics()
    print(f"\n【能量阈值管理器】")
    print(f"  初始阈值: {threshold_manager.initial_threshold:.3f} J")
    print(f"  当前阈值: {threshold_manager.threshold:.3f} J")
    print(f"  平均能耗: {stats['avg_energy']:.4f} J")
    print(f"  约束满足: {stats['constraint_satisfied']}")

    # 测试 EnergyQueue
    energy_queue = EnergyQueue(N=10, energy_threshold=0.35, nu=10)

    print(f"\n【虚拟能量队列】")
    for t in range(10):
        energy = np.random.uniform(0.2, 0.4, 10)
        Y = energy_queue.update(energy)
        if t % 5 == 0:
            print(f"  时隙 {t}: Y_sum = {np.sum(Y):.4f}, 稳定 = {energy_queue.is_stable()}")

    print("\n测试完成!")