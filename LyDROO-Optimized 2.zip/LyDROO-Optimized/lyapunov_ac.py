# -*- coding: utf-8 -*-
"""
【论文核心：Lyapunov-AC任务卸载算法】

本模块实现Lyapunov-AC强化学习任务卸载算法核心：
1. 整合能量阈值约束与虚拟队列
2. Actor-Critic架构实现
3. 漂移-惩罚优化

算法流程：
1. 动作生成 (Actor): 生成卸载偏好
2. 量化 (Quantizer): 离散化连续动作
3. 资源分配 (Critic): 计算时延和能耗
4. 策略更新: 根据Lyapunov漂移-惩罚更新策略
5. 队列更新: 更新数据队列Q和虚拟能量队列Y

参考文献：
- Bi S, et al. Lyapunov-guided deep reinforcement learning for stable online computation offloading[J]. 2021
- Huang L, et al. Deep reinforcement learning for online computation offloading in wireless powered mobile-edge computing networks[J]. 2020
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

from energy_threshold import EnergyThresholdManager, EnergyQueue
from virtual_queues import VirtualQueueManager


class LyapunovACCore:
    """
    【论文核心】Lyapunov-AC任务卸载算法

    整合两大创新点：
    - 创新点1：能量阈值约束（通过EnergyThresholdManager和EnergyQueue实现）
    - 创新点2：虚拟队列Lyapunov-AC（通过VirtualQueueManager实现）

    完整流程:
    1. 动作生成 (Actor): 生成卸载偏好
    2. 量化 (Quantizer): 离散化连续动作
    3. 资源分配 (Critic): 计算时延和能耗
    4. 策略更新: 根据Lyapunov漂移-惩罚更新策略
    5. 队列更新: 更新数据队列Q和虚拟能量队列Y
    """

    def __init__(self, config):
        """
        初始化Lyapunov-AC算法

        参数:
            config: 配置对象
        """
        self.config = config

        # ========== 创新点1：能量阈值约束 ==========
        self.threshold_manager = EnergyThresholdManager(
            initial_threshold=config.energy_threshold,
            learning_rate=config.threshold_learning_rate,
            window_size=config.threshold_window_size
        )

        # ========== 创新点2：虚拟队列Lyapunov-AC ==========
        self.queue_manager = VirtualQueueManager(
            N=config.N,
            energy_threshold=config.energy_threshold,
            nu=config.nu,
            enable_queue_constraint=config.enable_queue_length_constraint,
            queue_threshold=config.queue_threshold
        )

        # 初始化数据到达
        self.data_arrival = np.random.exponential(config.arrival_rate, config.N)

        # 历史记录
        self.history = {
            'delays': [],
            'energies': [],
            'rewards': [],
            'lyapunov': [],
            'Q_mean': [],
            'Y_mean': [],
            'thresholds': []
        }

        # 信道增益模型 (Rician fading)
        self.rician_K = 10  # Rician K因子 (dB)
        self.rician_sigma = 1

    def generate_channel_gain(self):
        """
        生成Rician衰落信道增益

        返回:
            channel_gains: 信道增益数组 [N]
        """
        A = np.sqrt(self.rician_K / (self.rician_K + 1))  # LOS幅度
        sigma = np.sqrt(1 / (2 * (self.rician_K + 1)))  # 散射分量

        # 复高斯随机变量
        h_complex = np.random.randn(self.config.N) + 1j * np.random.randn(self.config.N)
        h_complex = h_complex * sigma + A

        # 信道增益 = |h|²
        channel_gains = np.abs(h_complex) ** 2
        return channel_gains

    def generate_data_arrival(self):
        """
        生成数据到达率

        返回:
            data_arrival: 数据到达率 [N] (Mbits)
        """
        return np.random.exponential(self.config.arrival_rate, self.config.N)

    def get_state(self):
        """
        获取当前系统状态

        返回:
            state: 状态向量 [N*3]
                [Q_0, Y_0, A_0, Q_1, Y_1, A_1, ...]
        """
        # 从虚拟队列管理器获取队列状态
        queue_state = self.queue_manager.get_state(
            Q_scale=self.config.Q_scale,
            Y_scale=self.config.Y_scale
        )

        # 归一化数据到达率
        A = self.data_arrival / self.config.arrival_scale

        # 拼接为完整状态
        state = np.concatenate([queue_state, A])

        return state

    def compute_computation_rate(self, p, channel_gains):
        """
        计算处理速率

        参数:
            p: 卸载决策 [N]
            channel_gains: 信道增益 [N]

        返回:
            computation_rate: 处理速率 [N]
        """
        computation_rate = np.zeros(self.config.N)

        for i in range(self.config.N):
            # 本地处理速率
            local_rate = (1 - p[i]) * (self.config.f_local / self.config.cpu_cycles)

            # 边缘处理速率 (简化)
            if p[i] > 0:
                snr = self.config.transmit_power * channel_gains[i] / self.config.noise_power
                rate = self.config.bandwidth * np.log2(1 + snr)
                offload_rate = p[i] * min(rate, self.config.f_mec / self.config.cpu_cycles)
            else:
                offload_rate = 0

            computation_rate[i] = local_rate + offload_rate

        return computation_rate

    def compute_reward(self, p, channel_gains):
        """
        计算奖励

        奖励函数 = -w * delay - V * energy + Q相关项

        参数:
            p: 卸载决策 [N]
            channel_gains: 信道增益 [N]

        返回:
            reward: 奖励值
            delay: 总时延
            energy: 总能耗
        """
        from critic import Critic

        # 创建Critic实例（用于计算）
        critic = Critic(self.config.N, self.config)

        # 计算时延和能耗
        delays, energies = critic.allocator.allocate_resources(p, channel_gains)

        total_delay = np.sum(delays)
        total_energy = np.sum(energies)

        # 获取队列状态
        Q = self.queue_manager.data_queue.Q
        Y = self.queue_manager.energy_queue.Y

        # 奖励 = -w * delay - V * energy + Q相关项
        reward = -self.config.w * total_delay - self.config.V * total_energy

        # 添加队列稳定性奖励
        reward += np.sum(Q * (delays - 0.01))

        return reward, total_delay, total_energy

    def step(self, actor, critic):
        """
        执行一步算法

        参数:
            actor: Actor网络实例
            critic: Critic网络实例

        返回:
            result: 执行结果字典
        """
        # ========== 1. 获取状态 ==========
        state = self.get_state()

        # ========== 2. Actor生成动作 ==========
        continuous_action, quantized_action = actor.get_action(state)

        # ========== 3. 生成信道增益 ==========
        channel_gains = self.generate_channel_gain()

        # ========== 4. Critic计算奖励 ==========
        reward, delay, energy = self.compute_reward(quantized_action, channel_gains)

        # ========== 5. 计算处理量 ==========
        computation_rate = self._compute_computation_rate(quantized_action, channel_gains)

        # ========== 6. 更新队列 ==========
        self.queue_manager.update(self.data_arrival, computation_rate, energy)

        # ========== 7. 更新能量阈值 (如果启用) ==========
        if self.config.enable_adaptive_threshold:
            self.config.energy_threshold = self.threshold_manager.update(energy)
            self.queue_manager.energy_queue.energy_threshold = self.config.energy_threshold

        # ========== 8. 存储经验 ==========
        next_state = self.get_state()
        actor.store_transition(state, quantized_action, reward)

        # ========== 9. 更新网络 ==========
        if len(actor.memory) >= self.config.batch_size:
            actor_loss = actor.update(critic)

        # ========== 10. 记录历史 ==========
        self.history['delays'].append(delay)
        self.history['energies'].append(energy)
        self.history['rewards'].append(reward)
        self.history['lyapunov'].append(self.queue_manager.get_lyapunov_function())
        self.history['Q_mean'].append(np.mean(self.queue_manager.data_queue.Q))
        self.history['Y_mean'].append(np.mean(self.queue_manager.energy_queue.Y))
        self.history['thresholds'].append(self.config.energy_threshold)

        # ========== 11. 生成下一帧数据到达 ==========
        self.data_arrival = self.generate_data_arrival()

        return {
            'delay': delay,
            'energy': energy,
            'reward': reward,
            'lyapunov': self.queue_manager.get_lyapunov_function()
        }

    def _compute_computation_rate(self, p, channel_gains):
        """内部方法：计算处理速率"""
        return self.compute_computation_rate(p, channel_gains)

    def get_statistics(self):
        """
        获取统计信息

        返回:
            stats: 统计信息字典
        """
        if len(self.history['delays']) == 0:
            return {}

        recent = 50
        is_stable, info = self.queue_manager.check_stability()

        stats = {
            'avg_delay': np.mean(self.history['delays'][-recent:]) if len(self.history['delays']) >= recent else np.mean(self.history['delays']),
            'avg_energy': np.mean(self.history['energies'][-recent:]) if len(self.history['energies']) >= recent else np.mean(self.history['energies']),
            'avg_reward': np.mean(self.history['rewards'][-recent:]) if len(self.history['rewards']) >= recent else np.mean(self.history['rewards']),
            'lyapunov_final': self.history['lyapunov'][-1] if self.history['lyapunov'] else 0,
            'queue_stable': is_stable,
            'Q_mean': np.mean(self.history['Q_mean'][-recent:]) if len(self.history['Q_mean']) >= recent else 0,
            'Y_mean': np.mean(self.history['Y_mean'][-recent:]) if len(self.history['Y_mean']) >= recent else 0,
            'threshold': self.config.energy_threshold
        }

        return stats

    def reset(self):
        """重置算法状态"""
        self.queue_manager.reset()
        self.threshold_manager.reset()
        self.data_arrival = np.random.exponential(self.config.arrival_rate, self.config.N)
        self.history = {
            'delays': [],
            'energies': [],
            'rewards': [],
            'lyapunov': [],
            'Q_mean': [],
            'Y_mean': [],
            'thresholds': []
        }


def create_lyapunov_ac(config):
    """
    工厂函数：创建Lyapunov-AC算法实例

    参数:
        config: 配置对象

    返回:
        lyapunov_ac: Lyapunov-AC算法实例
    """
    return LyapunovACCore(config)


if __name__ == "__main__":
    # 测试Lyapunov-AC核心模块
    print("=" * 60)
    print("Lyapunov-AC核心模块测试")
    print("=" * 60)

    # 导入配置
    from config import Config

    config = Config()
    config.n_frames = 10  # 测试用少量帧

    # 创建算法实例
    lyapunov_ac = LyapunovACCore(config)

    print(f"\n初始化完成:")
    print(f"  用户数: {config.N}")
    print(f"  能量阈值: {config.energy_threshold} J")
    print(f"  控制参数V: {config.V}")
    print(f"  能量队列因子nu: {config.nu}")

    # 测试状态获取
    state = lyapunov_ac.get_state()
    print(f"\n状态维度: {len(state)}")

    # 测试信道生成
    channel_gains = lyapunov_ac.generate_channel_gain()
    print(f"信道增益范围: [{channel_gains.min():.4f}, {channel_gains.max():.4f}]")

    print("\n测试完成!")